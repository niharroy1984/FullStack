var Demo = /** @class */ (function () {
    function Demo() {
    }
    Demo.DoDemo = function () {
        console.log("Welcometo Java");
        return 1;
    };
    return Demo;
}());
Demo.DoDemo();
console.log(Demo.DoDemo());
