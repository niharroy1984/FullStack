class Demo{
    public static DoDemo():number{
        console.log("Welcometo Java")
        return 1;
    }
}

Demo.DoDemo();
console.log(Demo.DoDemo())