import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { MyCustomDirectiveDirective } from './my-custom-directive.directive';
import { NewappComponent } from './newapp/newapp.component';
import { HomeComponent } from './home/home.component';
import { ServcompComponent } from './servcomp/servcomp.component';
import { ContactusComponent } from './contactus/contactus.component';
import { MyappRoutingModule } from './myapp-routing/myapp-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    ParentComponent,
    ChildComponent,
    MyCustomDirectiveDirective,
    NewappComponent,
    HomeComponent,
    ServcompComponent,
    ContactusComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    MyappRoutingModule
  ],
  providers: [],
  //bootstrap: [AppComponent]  ---- Main application
  bootstrap: [NewappComponent]  // For Router code & Testing
})
export class AppModule { }
