import { MyCustomDirectiveDirective } from './my-custom-directive.directive';

describe('MyCustomDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MyCustomDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
