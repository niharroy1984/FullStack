import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
//import { EventEmitter } from 'events';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
//@Input('FromParentToChildData') childComponentContainerToHoldParentsValue;
@Input() public FromParentToChildData

@Output() public childEventToGetInParentComponent = new EventEmitter();
   constructor() {
    console.log('test')
   }

  ngOnInit() {
  }


  myClickHandler(){
    console.log('I am being pressed!!')
    this.childEventToGetInParentComponent.emit('From Child to Parent Data')
  }
}
