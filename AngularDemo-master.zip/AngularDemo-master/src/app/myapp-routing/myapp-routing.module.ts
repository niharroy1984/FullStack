import { NgModule, RootRenderer } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { ServcompComponent } from '../servcomp/servcomp.component';
import { ContactusComponent } from '../contactus/contactus.component';

const routepaths= [

  {path:'home',component:HomeComponent},
  {path:'services',component:ServcompComponent},
  {path:'contact',component:ContactusComponent}
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routepaths)
    
  ],
  exports:[RouterModule],
  declarations: []
})
export class MyappRoutingModule { }
