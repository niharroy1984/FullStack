export class Demo {
   public name:string;
    public address:string


    constructor(name:string,address:string){
        console.log('name is '+name);
        console.log('address is '+address);
        this.name=name;
        this.address=address;

    }
}
