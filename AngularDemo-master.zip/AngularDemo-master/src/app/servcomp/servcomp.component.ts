import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servcomp',
  templateUrl: './servcomp.component.html',
  styleUrls: ['./servcomp.component.css']
})
export class ServcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
