function login(){
    document.getElementById("user").innerHTML = "Hello Some User";
}